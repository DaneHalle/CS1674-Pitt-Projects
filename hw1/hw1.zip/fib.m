% 10
function [val] = fib(n)
    val = fibonacci(n);
end